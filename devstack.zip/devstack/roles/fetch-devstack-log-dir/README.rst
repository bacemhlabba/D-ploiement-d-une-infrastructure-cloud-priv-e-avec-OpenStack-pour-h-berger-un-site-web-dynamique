Fetch content from the devstack log directory

Copy logs from every host back to the zuul executor.

**Role Variables**

.. zuul:rolevar:: devstack_base_dir
   :default: /opt/stack

   The devstack base directory.
